typedef enum foo_enum_e			/* Sample enumeration type */
{
  FOO_ONE,				/* One fish */
  FOO_TWO,				/* Two fish */
  FOO_RED,				/* Red fish */
  FOO_BLUE,				/* Blue fish */
  FOO_PRIVATE				/* Private fish @private@ */
} foo_enum_t;
